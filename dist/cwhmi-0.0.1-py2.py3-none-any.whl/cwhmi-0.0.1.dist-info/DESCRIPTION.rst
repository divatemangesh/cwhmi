A dynamic front wth matplotlib like features for making HMI of machines with an interactive ipython command line.


