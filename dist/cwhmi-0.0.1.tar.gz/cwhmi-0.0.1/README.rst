


Contributors: jemshidkk@gmail.com
	      mr.mangesh@openmailbox.org


List of features or modification to be carried out.

	1. Make it package or module
	2. Name variable properly.
	3. Comment code.
	4. Make a note of the architecture of the code.
	5. Package the module
	6. Add a table
	7. Moidfy imshow to see the pixel value and xy co-ordiantes of the mouse point. 

Coding Guidelines 1.0
  dated : 21st of October 2016

	All methods and class shall have docstring along with code. 
	A docstring is made by putting the text in triple quotes after method or class declaration.
	Doc string shall list meaning of input arguments and returned values.
	Doc string shall have the coders name and the date of modification.
	Variables and objects name shall begin with small letters and use capital to separate words in the variable 		name. : eg: thisIsAVariable
	Function and class names shall start with capital letters and use capital letters to separate between words in 		function name. eg: thisIsAFunction
	File names shall use only small letters and words shall be separated with under scores.
	Import only necessary libraries
	Private functions and variables shall start with a leading underscore


